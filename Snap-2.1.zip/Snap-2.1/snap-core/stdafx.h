// empty StdAfx.h for non-Visual-C++ compilers
